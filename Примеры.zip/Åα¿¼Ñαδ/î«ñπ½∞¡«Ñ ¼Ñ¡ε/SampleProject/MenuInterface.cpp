#include <iostream>
#include "InputValidation.h"

using namespace std;

void ShowGreeting() {
	cout << "Greetings" << endl << endl;
}

void ShowMainMenu() {
	cout << "Main Menu" << endl;
	cout << "Please, make your selection" << endl;
	cout << "1 - Start game" << endl;
	cout << "2 - Options" << endl;
	cout << "3 - Quit" << endl;
	cout << "Selection: ";
}

void ShowOptionsMenu() {
	cout << "Options Menu" << endl;
	cout << "Please, make your selection" << endl;
	cout << "1 - Difficulty" << endl;
	cout << "2 - Sound" << endl;
	cout << "3 - Back" << endl;
	cout << "Selection: ";
}

void SetOptions() {
	optionsMenuItem choice = static_cast<optionsMenuItem>(0);
	double soundMode = 0.0;

	do {
		ShowOptionsMenu();
		choice = GetOptionsMenuItem();
		switch (choice) {
		case DIFFICULTY:
			cout << "Difficulty Stuff." << endl << endl;
			break;
		case SOUND:
			cout << "Select Sound Mode: ";
			soundMode = GetDouble();
			cout << soundMode << endl << endl;
			break;
		case BACK:
			cout << endl;
			break;
		default:
			cout << endl;
			break;
		}
	} while (choice != BACK);
}

void StartProgram() {
  mainMenuItem choice = static_cast<mainMenuItem>(0);

  do {
    ShowMainMenu();
    choice = GetMainMenuItem();
    switch (choice) {
    case START:
      cout << "You're dead!" << endl << endl;
      break;
    case OPTIONS:
      cout << endl;
      SetOptions();
      break;
    case QUIT:
      cout << "Goodbye!" << endl;
      break;
    default:
      cout << endl;
      break;
    }
  } while (choice != QUIT);
}
#include <iostream>
#include "MenuInterface.h"

int main() {
	ShowGreeting();

  StartProgram();

	system("PAUSE");
}
#pragma once

void ShowGreeting();
void StartProgram();
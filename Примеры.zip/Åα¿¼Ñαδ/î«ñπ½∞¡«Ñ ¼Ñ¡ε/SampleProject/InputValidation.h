#pragma once
#include "MenuItems.h"

double GetDouble();
mainMenuItem GetMainMenuItem();
optionsMenuItem GetOptionsMenuItem();
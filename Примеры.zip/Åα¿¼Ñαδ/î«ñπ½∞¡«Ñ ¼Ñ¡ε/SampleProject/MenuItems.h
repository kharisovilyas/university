#pragma once

enum mainMenuItem {
	START = 1, OPTIONS, QUIT
};

enum optionsMenuItem {
	DIFFICULTY = 1, SOUND, BACK
};